<?php

require './connection.php';

if($conn) {

    if(isset($_POST['contact'])) {
        $name= $_POST['f_name'];
        $age= $_POST['f_age'];
        $address= $_POST['f_address'];
        $phone = $_POST["f_phone"];
        $email= $_POST["f_email"];
        $message= $_POST["f_message"];

        $sqlc ="INSERT INTO entries(student_name, student_age, student_address, student_phone , student_email , student_message )
    VALUES('$name', '$age' , '$address', '$phone', '$email' , '$message')";


        if($conn->query($sqlc)) {

                 header("Location:../index.php?success");
                 
        }else {
            echo "error occured while submission";
        }

    }
    
    
    
    
} else echo "error occured";
    

?>