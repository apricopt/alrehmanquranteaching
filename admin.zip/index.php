<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>AL-Rahman Online Quran Tutoring Academy</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.css" rel="stylesheet">

  <!-- Custom fonts for this template -->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
  <link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>

  <!-- Custom styles for this template -->
  <link href="css/agency.css" rel="stylesheet">

  <style>
    /*------------------------------------
             particl effect started
------------------------------------*/


#particles-js{

position: absolute;
height: 100vh;
z-index: 2;
width: 100%;
}

  </style>

</head>

<body id="page-top">


  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger" href="#page-top">AL-Rahman Quran Academy </a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
       
        <i class="fas fa-bars"></i>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav text-uppercase ml-auto">
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#services">about us</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#about">how it works</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#portfolio">key features</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#team">our tutors</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#contact">Contact</a>
          </li>
          <li>
            
              <a href="donate.html" class="btn btn-primary btn-donate mt-2">Donate us</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>


  <!-- Header 
  <header class="masthead">
    <div class="container">
      <div class="intro-text">
        <div class="intro-lead-in">Welcome To Our Studio!</div>
        <div class="intro-heading text-uppercase">It's Nice To Meet You</div>
        <a class="btn btn-primary btn-xl text-uppercase js-scroll-trigger" href="#services">Tell Me More</a>
      </div>
    </div>
  </header>   -->

   <!-------------------particles effect  area started---------------------->
   <div id="particles-js"></div>
   <!-------------------particles effect area ended---------------------->


  <div id="demo" class="carousel slide carousel-fade" data-ride="carousel" style="width: 100%;">
    <ul class="carousel-indicators">
      <li data-target="#demo" data-slide-to="0" class="active"></li>
      <li data-target="#demo" data-slide-to="1"></li>
      <li data-target="#demo" data-slide-to="2"></li>
    </ul>
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="./img/slide3.jpg" alt="Los Angeles" class="slideimg"/>
        <div class="carousel-caption">
          <h3>Free Quran Teaching</h3>
          <p>Our professional tutor teaches you quran on software like skype.Anytime Anywhere.</p>
        </div>   
      </div>
      <div class="carousel-item">
        <img src="./img/slide1.jpg" alt="Chicago" class="slideimg" >
        <div class="carousel-caption">
          <h3>Tajweed Quran Reading / Nazra Quran</h3>
          <p>This is very basic course to learn to recite the holy Quran with proper tajweed rules.</p>
        </div>   
      </div>
      <div class="carousel-item">
        <img src="./img/slide2.jpg" alt="New York"  class="slideimg" >
        <div class="carousel-caption">
          <h3>Memorizing of Quran / Hifz e Quran</h3>
          <p>This course is designed for those who want to memorize the holy Quran online.</p>
        </div>   
      </div>
    </div>
    <a class="carousel-control-prev" href="#demo" data-slide="prev">
      <span class="carousel-control-prev-icon"></span>
    </a>
    <a class="carousel-control-next" href="#demo" data-slide="next">
      <span class="carousel-control-next-icon"></span>
    </a>
  </div>

  <!------Services 
  <section class="page-section" id="services">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 text-center">
          <h2 class="section-heading text-uppercase">Services</h2>
          <h3 class="section-subheading text-muted">Lorem ipsum dolor sit amet consectetur.</h3>
        </div>
      </div>
      <div class="row text-center">
        <div class="col-md-4">
          <span class="fa-stack fa-4x">
            <i class="fas fa-circle fa-stack-2x text-primary"></i>
            <i class="fas fa-shopping-cart fa-stack-1x fa-inverse"></i>
          </span>
          <h4 class="service-heading">E-Commerce</h4>
          <p class="text-muted">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima maxime quam architecto quo inventore harum ex magni, dicta impedit.</p>
        </div>
        <div class="col-md-4">
          <span class="fa-stack fa-4x">
            <i class="fas fa-circle fa-stack-2x text-primary"></i>
            <i class="fas fa-laptop fa-stack-1x fa-inverse"></i>
          </span>
          <h4 class="service-heading">Responsive Design</h4>
          <p class="text-muted">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima maxime quam architecto quo inventore harum ex magni, dicta impedit.</p>
        </div>
        <div class="col-md-4">
          <span class="fa-stack fa-4x">
            <i class="fas fa-circle fa-stack-2x text-primary"></i>
            <i class="fas fa-lock fa-stack-1x fa-inverse"></i>
          </span>
          <h4 class="service-heading">Web Security</h4>
          <p class="text-muted">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima maxime quam architecto quo inventore harum ex magni, dicta impedit.</p>
        </div>
      </div>
    </div>
  </section>              


 About -->
  <section class="page-section" id="services" style="margin-top: " >
    <div class="container">
      <div class="row">
        <div class="col-lg-12 text-center">
          <h2 class="section-heading text-uppercase">About us</h2>
          <h3 class="section-subheading text-muted">Al-Rehman  a reliable Online Quran tutoring Academy  provides you an opportunity to learn the rules of Tajweed that is better for your kids, adults and new muslims to lead their lives according to the Islamic rules. Now students of any age in any country can learn to recite Quran at their own schedule. Parents can now watch their children learning Holy Quran in front of their eyes and we are sure that you will be fully satisfied with the quality of "teaching of Quran".<br>
          
Learn how to Read Quran with Tajweed<br>
Learn Quran Word by word<br>
Memorization of Quran<br>
Islamic Daily Duas<br>
Teach How to perform Namaz<br>

            .</h3>
        </div>
      </div>
</section>
  
  
  <section class="page-section" id="Services">
    <div class="container">
      
      <div class="row">
        <div class="col-lg-12">
          <ul class="timeline">
            <li>
              <div class="timeline-image">
                <img class="rounded-circle img-fluid" src="img/concept1.jpg" alt="">
              </div>
              <div class="timeline-panel">
                <div class="timeline-heading">
                  
                  <h4 class="subheading">Interpretation of Islamic concepts for Muslim brothers and sisters
                  </h4>
                </div>
                <div class="timeline-body">
                  <p class="text-muted">We offer classes for the students of all age groups. By the Grace of Allah Subhana-Wa-Tala, students of many countries are benefiting from our services and enjoying the opportunity to learn Quran online. We have many of satisfied students, which is the sign of our performance and credibility.
                  </p>
                </div>
              </div>
            </li>
            <li class="timeline-inverted">
              <div class="timeline-image">
                <img class="rounded-circle img-fluid" src="img/concept2.jpg" alt="">
              </div>
              <div class="timeline-panel">
                <div class="timeline-heading">
                  
                  <h4 class="subheading">Tajweed Quran Reading / Nazra Quran
                  </h4>
                </div>
                <div class="timeline-body">
                  <p class="text-muted">This is very basic course to learn to recite the holy Quran with proper tajweed rules . We will develop the students to identify Arabic alphabets with the help of Noorani Qaida. On the completion of this course students will be able to read the holy Quran with Tajweed rules. You will be taught basic Islamic Education with Quran learning Classes like Masnoon Duas , Proper ways of Prayer and Wazzu, 6 Kalmas, Ayat al Kursi, Dua-e-Qunoot  etc. This course is especially designed for kids and for those adults who want to take first step into learning Quran reading starting from Arabic Alphabets. In this course we ensure you very closed attention of your teacher and very good interpersonal and communication skills to guide you step by step . Our aim in this course is to make students to be able to read the holy Quran with tajweed rules.
                  </p>
                </div>
              </div>
            </li>
            <li>
              <div class="timeline-image">
                <img class="rounded-circle img-fluid" src="img/concept3.jpg" alt="">
              </div>
              <div class="timeline-panel">
                <div class="timeline-heading">
              
                  <h4 class="subheading">Memorizing of Quran / Hifz e Quran
                  </h4>
                </div>
                <div class="timeline-body">
                  <p class="text-muted">Memorizing Quran simply means learning it by heart. At the time of Prophet (peace be upon him), writing was an uncommon style of storing matters; thus, memorization and oral transmission were the most effective modes of preserving information.This course is designed for those who want to memorize the holy Quran online. Your class will be assigned to a tutor who will be Hafiz-Ul-Quran and will guide you step by step giving you specific lessons every day as a home work . The way would be just like physical classes in Madrassas / Islamic centers . You will memorize the holy Quran at your own pace
                  </p>
                </div>
              </div>
            </li>
            
            <li class="timeline-inverted">
              <div class="timeline-image">
                <h4>Islamic 
                  <br>teaching!</h4>
              </div>
              <div class="timeline-panel">
                <div class="timeline-heading">
                  
                  <h4 class="subheading">Islamic Concepts Teachings
                  </h4>
                </div>
                <div class="timeline-body">
                  <p class="text-muted">We also teach students about Interpretation of Islamic concepts to have a good understanding & become enlightened to the splendid teachings of Islam.

                  </p>
                </div>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </section>

                       <!----------------- about end------------------>


                       <div class="container my-5">


                        <!--Section: Content-->
                        <section class="text-center dark-grey-text" id="about">
                      
                          <!-- Section heading -->
                          <h3 class="font-weight-bold pb-2 mb-4">How It Works?</h3>
                          <!-- Section description -->
                          <p class="text-muted w-responsive mx-auto mb-5">At an agreed time, teacher and student come online. With help of VOIP software like Skype, They talk to each other just like a telephone conversation but through computer and a screen sharing software makes them enable to see the same lesson on their computer screen .Teacher can highlight letters and words to the Qur’an to enhance the understanding of the student.
                          </p>
                      
                          <!-- Grid row -->
                          <div class="row">
                            <!-- Grid column -->
                            <div class="col-lg-4 col-md-12 mb-4">
                              <!-- Rotating card -->
                              <div class="card-wrapper">
                                <div id="card-1" class="card card-rotating text-center">
                                  <!-- Front Side -->
                                  <div class="face front">
                                    <!-- Image -->
                                    <div class="card-up">
                                      <img class="card-img-top" src="./img/how1.jpg" alt="Team member card image">
                                    </div>
                                  </div>
                                  <div class="face back">
                                    <!-- Content -->
                                    <div class="card-body">
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <!-- Grid column -->
                    
                            <div class="col-lg-4 col-md-12 mb-4">
                              <!-- Rotating card -->
                              <div class="card-wrapper">
                                <div id="card-1" class="card card-rotating text-center">
                                  <!-- Front Side -->
                                  <div class="face front">
                                    <!-- Image -->
                                    <div class="card-up">
                                      <img class="card-img-top" src="./img/how2.jpg" alt="Team member card image">
                                    </div>
                                  </div>
                                  <div class="face back">
                                    <!-- Content -->
                                    <div class="card-body">
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <!-- Grid column -->
                            <div class="col-lg-4 col-md-12 mb-4">
                              <!-- Rotating card -->
                              <div class="card-wrapper">
                                <div id="card-1" class="card card-rotating text-center">
                                  <!-- Front Side -->
                                  <div class="face front">
                                    <!-- Image -->
                                    <div class="card-up">
                                      <img class="card-img-top" style="height: 230px"; src="./img/how3.jpg" alt="Team member card image">
                                    </div>
                                  </div>
                                  <div class="face back">
                                    <!-- Content -->
                                    <div class="card-body">
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <!-- Grid column -->
                      
                           
                           
                        
                      
                          </div>
                          <!-- Grid row -->
                      
                        </section>
                        <!--Section: Content-->
                      
                      
                      </div>
                     
                       
  <!-- KEY FEATURES -->
 
  
  <div class="container mt-5" id="portfolio">

   
    <!--Section: Content-->
    <section class="text-center dark-grey-text">
  
      <!-- Section heading -->
      <h2 class="section-heading text-uppercase">Key Features</h2>
      <BR> <BR> 
      
  
      <div class="wrapper-carousel-fix">
        <!-- Carousel Wrapper -->
        <div id="carousel-example-1" class="carousel no-flex testimonial-carousel slide carousel" data-ride="carousel"
          data-interval="false">
          <!--Slides-->
          <div class="carousel-inner" role="listbox">
            <!--First slide-->
            <div class="carousel-item active">
              <div class="testimonial">
                <h4 class="section-heading text-uppercase">Time of Students Choice</h4>
                <!--Avatar-->
                <div class="avatar mx-auto mb-4">
                  <img src="./img/how1.jpg" class="rounded-circle img-fluid"
                    alt="First sample avatar image">
                </div>
                <!--Content-->
                <p>
                  <i class="fas fa-quote-left"></i>Al-Rahman Academy is available online round the clock so students can choose time of their choice. No matters where you live on world you can have our services Online at your convenient tim

                </p>
                <h4 class="font-weight-bold">Time of Students Choice
                </h4>
                
                <!--Review-->
                <i class="fas fa-star blue-text"> </i>
                <i class="fas fa-star blue-text"> </i>
                <i class="fas fa-star blue-text"> </i>
                <i class="fas fa-star blue-text"> </i>
                <i class="fas fa-star-half-alt blue-text"> </i>
              </div>
            </div>
            <!--First slide-->
            <!--Second slide-->
            <div class="carousel-item">
              <div class="testimonial">
                <h4 class="section-heading text-uppercase">Female Teacher
                </h4>
                <!--Avatar-->
                <div class="avatar mx-auto mb-4">
                  <img src="./img/female.jpg" class="rounded-circle img-fluid"
                    alt="Second sample avatar image">
                </div>
                <!--Content-->
                <p>
                  <i class="fas fa-quote-left"></i>Al-Rahman Academy has female teachers for online Quran teaching for our sisters & kids who feel easiness & comfortable to learn Quran online with female tutors.
                </p>
              
                <h6 class="font-weight-bold my-3">Female Tutors Are Available
                </h6>
                <!--Review-->
                <i class="fas fa-star blue-text"> </i>
                <i class="fas fa-star blue-text"> </i>
                <i class="fas fa-star blue-text"> </i>
                <i class="fas fa-star blue-text"> </i>
                <i class="fas fa-star blue-text"> </i>
              </div>
            </div>
            <!--Second slide-->
      
          <!--Controls-->


    
      
          <a class="carousel-control-prev left carousel-control" href="#carousel-example-1" role="button"
            data-slide="prev">
            <span class="carousel-control-next-icon icofont-rounded-right" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next right carousel-control" href="#carousel-example-1" role="button"
            data-slide="next">
            <span class="carousel-control-next-icon icofont-rounded-left" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a>
          <!--Controls--->
        </div>
        <!-- Carousel Wrapper -->
      </div>
  
    </section>
    <!--Section: Content-->
  
  
  </div>


 

  


<div class="container-fluid pt-5 my-5 z-depth-1" id="team">
  <section class="p-md-3 mx-md-5 text-center text-lg-left">
    <h2 class="text-center mx-auto font-weight-bold mb-4 pb-2">Our Tutors</h2>
    <p class="text-muted w-responsive mx-auto mb-5">Quran teaching is the big responsibility so in order to fulfill this responsibility we hire the best tutors for our students. For giving Online Quran Classes to our students, we hire full time tutors. The tutors are well experienced in Quran Teaching online. Every student is given an individual attention by an online Quran teacher. The teachers are not only arranged for the adult students, but they also give online Quran classes for kids.

    </p>
    <h4 class="text-center mx-auto font-weight-bold mb-4 pb-2">The main features of the tutors include :
    </h4>
    <div class="row d-flex justify-content-center">
      
      <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
      
        <div class="p-4">
          <div
            class="avatar w-100 white d-flex justify-content-center align-items-center"
          >
            <img
              src="./img/lastlogo5.png"
              class="img-fluid rounded-circle z-depth-1"
            />
          </div>
          <div class="text-center mt-3">
            <h6 class="font-weight-bold pt-2">Well Experienced & Qualified in Quranic and Islamic Teachings.
            </h6>
           
          </div>
        </div>
      </div>
   
      <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
        <div class="p-4">
          <div
            class="avatar w-100 white d-flex justify-content-center align-items-center"
          >
            <img
              src="./img/lastlogo1.png"
              class="img-fluid rounded-circle z-depth-1"
            />
          </div>
          <div class="text-center mt-3">
            <h6 class="font-weight-bold pt-2">Fully Trained to teach easily online
            </h6>
            
          </div>
        </div>
      </div>
     
      
      <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
        <div class="p-4">
          <div
            class="avatar w-100 white d-flex justify-content-center align-items-center"
          >
            <img
              src="./img/lastlogo3.png"
              class="img-fluid rounded-circle z-depth-1"
            />
          </div>
          <div class="text-center mt-3">
            <h6 class="font-weight-bold pt-2">Huffaz-e-Quran tutors for the memorization class
            </h6>
            
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
        <div class="p-4">
          <div
            class="avatar w-100 white d-flex justify-content-center align-items-center"
          >
            <img
              src="./img/lastlogo4.png"
              class="img-fluid rounded-circle z-depth-1"
            />
          </div>
          <div class="text-center mt-3">
            <h6 class="font-weight-bold pt-2">Both Male and Female Tutors</h6>
           
          </div>
        </div>
      </div>
    </div>
  </section>
</div>

    
  <!-- Contact -->
  <section class="page-section" id="contact">
    <div class="container z-depth-1 my-5 px-0">

      <!--Section: Content-->
    
    
        <div class="rgba-black-strong rounded p-5">
    
          <!-- Section heading -->
          <h3 class="text-center font-weight-bold text-white mt-3 mb-5">Contact Us</h3>
    
         
    
            <div class="row d-flex justify-content-center">
            <div class="col-md-6 mb-4">

<div class="card">
  <div class="card-body px-4">

    <!-- Name -->
    <form Method="POST" action="./include/form_handler.php">
    <div class="md-form md-outline mt-0">
      <input name="f_name" type="text" id="name" class="form-control" required>
      <label for="name">Student Name</label>
    </div>
    <!-- age -->
    <div class="md-form md-outline mt-0">
      <input name="f_age" type="text" id="name" class="form-control" required>
      <label for="name">Student Age</label>
    </div>
    <!-- address-->
    <div class="md-form md-outline mt-0">
      <input name="f_address" type="text" id="name" class="form-control" required>
      <label for="name">Student Address</label>
    </div>
     <!-- phone-->
     <div class="md-form md-outline mt-0">
      <input name="f_phone" type="text" id="name" class="form-control" required>
      <label for="name">Student phone:</label>
    </div>
    <!-- Email -->
    <div class="md-form md-outline">
      <input name="f_email" type="text" id="email" class="form-control" required>
      <label for="email">Your Email Address</label>
    </div>
    <!-- Message -->
    <div class="md-form md-outline">
      <textarea name="f_message" id="message" class="md-textarea form-control" rows="3" placeholder="(optional)"></textarea>
      <label for="message">Your Message</label>
    </div>

    <button type="submit" class="btn btn-primary btn-md btn-block ml-0 mb-0" name="contact">Submit inquiry</button>
</form>
  </div>
</div>

</div>
         
              <div class="col-md-5 offset-md-1 mt-md-4 mb-4 text-white ">
<!--     
                <h5 class="font-weight-bold">Address</h5>
                <p class="mb-0">1632 Main Street</p>
                <p class="mb-0">New York, 94126</p>
                <p class="mb-4 pb-2">United States</p> -->
                <h5 class="font-weight-bold">Sype ID: </h5>
                <p class="mb-4 pb-2">al.rehman7843@gmail.com</p>
    
                <h5 class="font-weight-bold">Phone</h5>
                <p class="mb-4 pb-2">+ 92 311 9579924</p>
    
                <h5 class="font-weight-bold">Email</h5>
                <p>al.rehman7843@gmail.com</p>
    
              </div>
            </div>
    
      
    
        </div>
    
      </section>
      <!--Section: Content-->
    
    
    </div>

  

  <!-- Footer -->
  <footer class="footer">
    <div class="container">
      <div class="row align-items-center">
        <div class="col-md-4">
          <span class="copyright">Copyright &copy; Al-Rahman Quran Academy 2020</span>
        </div>
        <div class="col-md-4">
          <ul class="list-inline social-buttons">
            <li class="list-inline-item">
              <a href="https://twitter.com/al_teaching">
                <i class="fab fa-twitter"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a href="https://www.facebook.com/Al-Rehman-online-Quran-Teaching-112580713804734/?modal=admin_todo_tour&_rdc=1&_rdr">
                <i class="fab fa-facebook-f"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a href="https://www.instagram.com/onlinequranteaching01/">
                <i class="fab fa-instagram"></i>
              </a>
            </li>
          </ul>
        </div>
        <div class="col-md-4">
          <ul class="list-inline quicklinks">
            <li class="list-inline-item">
              <a href="#">Privacy Policy</a>
            </li>
            <li class="list-inline-item">
              <a href="donate.html" class="btn btn-primary btn-donate">Donate us</a>
              <a href="#">Terms of Use</a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </footer>

  <!-- Portfolio Modals -->



  <!-- Bootstrap core JavaScript -->

  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Contact form JavaScript -->
  <script src="js/jqBootstrapValidation.js"></script>
  <script src="js/contact_me.js"></script>

  <!-- Custom scripts for this template -->
  <script src="js/agency.min.js"></script>


   <!-- particles scripts here -->
   <script src="js/particles.min.js"></script>
   <script src="js/app.js"></script>

</body>

</html>
